# ⚡ Starter Kit Pro Builder — Tu Estudio y Robot Publicador 24/7 ($0/mes)
**Diseñado por Talento con Tarifa (`talentocontarifa.lat`)**

¡Bienvenido! Este paquete contiene toda la arquitectura lista para usar con **Google Antigravity IDE (Gratis)**, **Claude Code** o **Cursor**.

## 📂 ¿Qué incluye esta carpeta?
1. **`.gemini/skills/` y `.claude/skills/`**: Las 3 Skills oficiales (`robot-video-assistant`, `hyperframes-video-factory`, `github-actions-publisher`) para que tu agente de IA haga todo el trabajo por ti.
2. **`scripts/voice_elevenlabs_hybrid.py`**: Conector directo a la **API oficial de ElevenLabs (`POST /v1/text-to-speech/{voice_id}`)** con caché inteligente `SHA-256` en `voice_cache/` y respaldo automático e ilimitado a **Microsoft Edge-TTS**.
3. **`.github/workflows/robot_publicador.yml`**: El reloj despertador en la nube (`cron`) con permiso `models: read` para usar IA gratuita en GitHub Actions y escudo anti-pausa de 60 días.
4. **`scripts/generate_caption.js` y `scripts/publish_social.js`**: Redactor automático de copys virales + publicador en Facebook Reels, Instagram Reels y YouTube Shorts.
5. **`scripts/export_metricool_csv.js`**: Generador de lote `.csv` para quienes prefieren programar sus redes (incluyendo TikTok en Público) con el plan gratuito de **Metricool**.

## 🚀 Inicio Rápido en 3 Pasos
1. Abre esta carpeta en **Antigravity IDE** (o ejecuta `claude` en la terminal).
2. Copia `.env.example` a `.env` y coloca tu `ELEVENLABS_API_KEY` y `ELEVENLABS_VOICE_ID`.
3. Abre tus 4 Manuales Interactivos (`.html` o `.pdf`) y usa los botones verdes **"COPIAR PROMPT EN 1 CLIC"**.
