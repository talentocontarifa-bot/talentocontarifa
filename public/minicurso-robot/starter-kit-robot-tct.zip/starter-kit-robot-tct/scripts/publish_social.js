/**
 * scripts/publish_social.js — Publicador Automático hacia Meta Graph API (FB + IG Reels) y YouTube Shorts
 * =======================================================================================================
 * Lee el turno preparado en estado_rotacion.json y publica en las redes cuyos Secrets estén configurados.
 */

const fs = require('fs');
const path = require('path');

const STATE_FILE = path.join(process.cwd(), 'estado_rotacion.json');

async function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function publishInstagramReel(videoPublicUrl, caption) {
  const igUserId = (process.env.IG_USER_ID || '').trim();
  const token = (process.env.META_PAGE_TOKEN || '').trim();
  if (!igUserId || !token) {
    console.log('ℹ️ [Instagram] IG_USER_ID o META_PAGE_TOKEN no configurados. Saltando paso.');
    return;
  }

  console.log('📸 [Instagram] Creando contenedor de Reel en Graph API v21.0...');
  const createRes = await fetch(`https://graph.facebook.com/v21.0/${igUserId}/media`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      media_type: 'REELS',
      video_url: videoPublicUrl,
      caption: caption,
      share_to_feed: true,
      access_token: token,
    }),
  });
  const createData = await createRes.json();
  if (!createData.id) {
    throw new Error(`Error al crear contenedor IG: ${JSON.stringify(createData)}`);
  }

  const creationId = createData.id;
  for (let attempt = 1; attempt <= 12; attempt++) {
    await sleep(5000);
    const statusRes = await fetch(
      `https://graph.facebook.com/v21.0/${creationId}?fields=status_code&access_token=${token}`
    );
    const statusData = await statusRes.json();
    console.log(`   ⏳ Estado contenedor IG (${attempt}/12): ${statusData.status_code}`);
    if (statusData.status_code === 'FINISHED') break;
    if (statusData.status_code === 'ERROR') {
      throw new Error(`Error procesando video en IG: ${JSON.stringify(statusData)}`);
    }
  }

  const pubRes = await fetch(`https://graph.facebook.com/v21.0/${igUserId}/media_publish`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      creation_id: creationId,
      access_token: token,
    }),
  });
  const pubData = await pubRes.json();
  console.log('✅ [Instagram Reel Publicado] ID:', pubData.id);
}

async function publishFacebookReel(videoPublicUrl, description) {
  const pageId = (process.env.FB_PAGE_ID || '').trim();
  const token = (process.env.META_PAGE_TOKEN || '').trim();
  if (!pageId || !token) {
    console.log('ℹ️ [Facebook] FB_PAGE_ID o META_PAGE_TOKEN no configurados. Saltando paso.');
    return;
  }

  console.log('📘 [Facebook] Publicando video en Fan Page...');
  const res = await fetch(`https://graph.facebook.com/v21.0/${pageId}/videos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      file_url: videoPublicUrl,
      description: description,
      access_token: token,
    }),
  });
  const data = await res.json();
  console.log('✅ [Facebook Reel Publicado] Respuesta:', data.id || JSON.stringify(data));
}

async function main() {
  if (!fs.existsSync(STATE_FILE)) {
    console.log('⚠️ No existe estado_rotacion.json. Ejecuta primero node scripts/generate_caption.js');
    return;
  }

  const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  const repo = process.env.GITHUB_REPOSITORY || 'tu-usuario/tu-repo';
  const branch = process.env.GITHUB_REF_NAME || 'main';
  const rawVideoUrl = `https://raw.githubusercontent.com/${repo}/${branch}/videos/${encodeURIComponent(
    state.selectedVideo
  )}`;

  console.log(`🚀 Preparando disparo para: ${state.selectedVideo}`);
  console.log(`🔗 URL Raw del video: ${rawVideoUrl}`);

  await publishFacebookReel(rawVideoUrl, `${state.title}\n\n${state.description}`);
  await publishInstagramReel(rawVideoUrl, `${state.title}\n\n${state.description}`);
}

main().catch((err) => {
  console.error('❌ Error en publish_social.js:', err);
  process.exit(1);
});
