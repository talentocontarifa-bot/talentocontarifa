/**
 * scripts/voice_elevenlabs_hybrid.py — Motor Híbrido: API Oficial de ElevenLabs + Caché SHA-256 + Respaldo Edge-TTS
 * =================================================================================================================
 * Mini-Curso "Arma tu Estudio y Robot Publicador 24/7" — Talento con Tarifa (talentocontarifa.lat)
 *
 * Cómo funciona:
 * 1. Lee ELEVENLABS_API_KEY y ELEVENLABS_VOICE_ID desde tu archivo .env privado.
 * 2. Calcula el hash SHA-256 de cada frase y la guarda en voice_cache/ para no gastar créditos repetidos.
 * 3. Usa por defecto el modelo "eleven_flash_v2_5" (cobra 0.5 créditos/letra = ¡20,000 caracteres gratis/mes!).
 * 4. Si se agota tu cuota gratuita de ElevenLabs (error 401/429) o no pusiste API Key, salta automáticamente
 *    a Microsoft Edge-TTS ($0.00 e ilimitado) para que tu fábrica de videos nunca se detenga.
 */

import os
import sys
import hashlib
import subprocess
import urllib.request
import urllib.error
import json


def load_env_file(env_path=".env"):
    if not os.path.exists(env_path):
        return
    with open(env_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def synthesize_voice(text: str, out_dir: str = "voice_cache", fallback_voice: str = "es-MX-JorgeNeural") -> str:
    load_env_file()
    os.makedirs(out_dir, exist_ok=True)

    api_key = os.environ.get("ELEVENLABS_API_KEY", "").strip()
    voice_id = os.environ.get("ELEVENLABS_VOICE_ID", "pNInz6obpgDQGcFmaJgB").strip()
    model_id = os.environ.get("ELEVENLABS_MODEL_ID", "eleven_flash_v2_5").strip()

    # 1. Revisar Caché SHA-256 para ahorrar hasta 80% de créditos
    cache_key = hashlib.sha256(f"{voice_id}:{model_id}:{text}".encode("utf-8")).hexdigest()[:16]
    out_mp3 = os.path.join(out_dir, f"voz_{cache_key}.mp3")

    if os.path.exists(out_mp3) and os.path.getsize(out_mp3) > 500:
        print(f"♻️ [Caché SHA-256] Reutilizando audio sin gastar créditos: {out_mp3}")
        return out_mp3

    # 2. Llamar a la API Oficial de ElevenLabs (POST /v1/text-to-speech/{voice_id})
    if api_key and not api_key.startswith("sk_pon_aqui"):
        url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}?output_format=mp3_44100_128"
        payload = json.dumps({
            "text": text,
            "model_id": model_id,
            "voice_settings": {
                "stability": 0.45,
                "similarity_boost": 0.80,
                "style": 0.25,
                "use_speaker_boost": True
            }
        }).encode("utf-8")

        req = urllib.request.Request(
            url,
            data=payload,
            headers={
                "xi-api-key": api_key,
                "Content-Type": "application/json",
                "Accept": "audio/mpeg",
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=45) as resp:
                audio_bytes = resp.read()
                with open(out_mp3, "wb") as f:
                    f.write(audio_bytes)
                print(f"🎙️ [ElevenLabs API OK] Audio generado ({len(audio_bytes)} bytes) -> {out_mp3}")
                return out_mp3
        except urllib.error.HTTPError as e:
            print(f"⚠️ [ElevenLabs API HTTP {e.code}] Activando respaldo ilimitado con Microsoft Edge-TTS...")
        except Exception as e:
            print(f"⚠️ [ElevenLabs API Error: {e}] Activando respaldo ilimitado con Microsoft Edge-TTS...")

    # 3. Respaldo 100% Ilimitado y Gratis con Microsoft Edge-TTS
    cmd = [
        sys.executable, "-m", "edge_tts",
        "--voice", fallback_voice,
        "--rate=+4%",
        "--text", text,
        "--write-media", out_mp3
    ]
    subprocess.run(cmd, check=True)
    print(f"🎙️ [Edge-TTS Gratis OK] Audio generado -> {out_mp3}")
    return out_mp3


if __name__ == "__main__":
    sample_text = (
        "Hola, este es mi estudio automático de videos conectado a la API de ElevenLabs "
        "con caché inteligente y respaldo gratuito."
    )
    if len(sys.argv) > 1:
        sample_text = " ".join(sys.argv[1:])
    synthesize_voice(sample_text)
