/**
 * scripts/generate_caption.js — Selección de Video en Rotación + Generador de Copy con IA Gratis
 * ==============================================================================================
 * Soporta:
 *  1. GitHub Models (gratis con el mismo GITHUB_TOKEN automático del workflow).
 *  2. Google Gemini API Free Tier (si configuraste GEMINI_API_KEY en GitHub Secrets).
 *  3. Plantilla persuasiva de respaldo si prefieres no usar ninguna llave externa.
 */

const fs = require('fs');
const path = require('path');

const VIDEOS_DIR = path.join(process.cwd(), 'videos');
const STATE_FILE = path.join(process.cwd(), 'estado_rotacion.json');

function pickNextVideo() {
  if (!fs.existsSync(VIDEOS_DIR)) {
    fs.mkdirSync(VIDEOS_DIR, { recursive: true });
  }
  const files = fs
    .readdirSync(VIDEOS_DIR)
    .filter((f) => f.toLowerCase().endsWith('.mp4'))
    .sort();

  if (files.length === 0) {
    console.log('⚠️ No hay archivos .mp4 en videos/ todavía. Usando modo demostración.');
    return { filename: '01_demo_reel.mp4', index: 0, total: 1 };
  }

  const override = (process.env.VIDEO_OVERRIDE || '').trim();
  if (override && files.includes(override)) {
    return { filename: override, index: files.indexOf(override), total: files.length };
  }

  let state = { lastIndex: -1 };
  if (fs.existsSync(STATE_FILE)) {
    try {
      state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    } catch (_) {}
  }

  const nextIndex = (Number(state.lastIndex ?? -1) + 1) % files.length;
  return { filename: files[nextIndex], index: nextIndex, total: files.length };
}

async function generateCaptionWithAI(topicFromFilename) {
  const prompt = `Escribe un título corto de máximo 80 caracteres y una descripción persuasiva con 5 hashtags en español para un Reel/Short sobre: "${topicFromFilename}". Responde en JSON exacto con las llaves "title" y "description".`;

  // Opción 1: GitHub Models Gratis con GITHUB_TOKEN
  if (process.env.GITHUB_TOKEN) {
    try {
      const res = await fetch('https://models.inference.ai.azure.com/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [{ role: 'user', content: prompt }],
          response_format: { type: 'json_object' },
          temperature: 0.7,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        const parsed = JSON.parse(data.choices[0].message.content);
        console.log('🧠 [GitHub Models IA Gratis] Copy generado con éxito.');
        return parsed;
      }
    } catch (err) {
      console.warn('⚠️ Aviso GitHub Models:', err.message);
    }
  }

  // Opción 2: Google Gemini API Free Tier
  if (process.env.GEMINI_API_KEY) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { responseMimeType: 'application/json' },
        }),
      });
      if (res.ok) {
        const data = await res.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
        if (text) {
          console.log('🧠 [Gemini API Free] Copy generado con éxito.');
          return JSON.parse(text);
        }
      }
    } catch (err) {
      console.warn('⚠️ Aviso Gemini API:', err.message);
    }
  }

  // Opción 3: Plantilla automática de respaldo
  return {
    title: `⚡ ${topicFromFilename} #Shorts`,
    description: `Descubre hoy: ${topicFromFilename}.\n\nSíguenos para más contenido diario.\n#Reels #Shorts #Automatizacion #IA #Emprendimiento`,
  };
}

async function main() {
  const picked = pickNextVideo();
  const cleanTopic = picked.filename
    .replace(/\.mp4$/i, '')
    .replace(/^\d+[_-]?/, '')
    .replace(/[_-]+/g, ' ');

  const copy = await generateCaptionWithAI(cleanTopic || 'Contenido de Valor');

  const payload = {
    updatedAt: new Date().toISOString(),
    lastIndex: picked.index,
    selectedVideo: picked.filename,
    title: copy.title,
    description: copy.description,
  };

  fs.writeFileSync(STATE_FILE, JSON.stringify(payload, null, 2), 'utf8');
  console.log('✅ Turno preparado:', payload);
}

main().catch((err) => {
  console.error('❌ Error en generate_caption.js:', err);
  process.exit(1);
});
