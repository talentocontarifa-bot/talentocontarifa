/**
 * scripts/export_metricool_csv.js — Generador de Calendario CSV para Metricool Gratis (Vía B)
 * ===========================================================================================
 * Crea un archivo calendario_metricool.csv listo para importar o copiar en tu cuenta gratuita de Metricool.
 */

const fs = require('fs');
const path = require('path');

const VIDEOS_DIR = path.join(process.cwd(), 'videos');
const OUT_CSV = path.join(process.cwd(), 'calendario_metricool.csv');

function main() {
  if (!fs.existsSync(VIDEOS_DIR)) {
    fs.mkdirSync(VIDEOS_DIR, { recursive: true });
  }
  const files = fs
    .readdirSync(VIDEOS_DIR)
    .filter((f) => f.toLowerCase().endsWith('.mp4'))
    .sort();

  const list = files.length > 0 ? files : ['01_reel_ejemplo.mp4', '02_reel_oferta.mp4', '03_reel_tips.mp4'];
  const rows = ['Text,Date,Time,VideoFile,TikTok,Instagram,Facebook,YouTubeShorts'];

  const baseDate = new Date();
  list.forEach((file, idx) => {
    const pubDate = new Date(baseDate.getTime() + (idx + 1) * 86400000);
    const yyyy = pubDate.getFullYear();
    const mm = String(pubDate.getMonth() + 1).padStart(2, '0');
    const dd = String(pubDate.getDate()).padStart(2, '0');
    const cleanName = file.replace(/\.mp4$/i, '').replace(/[_-]+/g, ' ');
    const text = `"⚡ ${cleanName} — Descubre más hoy mismo #Reels #Shorts #TikTok"`;
    rows.push(`${text},${yyyy}-${mm}-${dd},14:00:00,videos/${file},true,true,true,true`);
  });

  fs.writeFileSync(OUT_CSV, rows.join('\n'), 'utf8');
  console.log(`✅ Archivo generado con éxito: ${OUT_CSV}`);
}

main();
