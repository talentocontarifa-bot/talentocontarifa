---
name: github-actions-publisher
description: "Arquitecto del Robot Fantasma en GitHub Actions (.github/workflows/robot_publicador.yml) del Mini-Curso de Talento con Tarifa. Úsala siempre que el usuario pida configurar, programar horarios cron, conectar GitHub Secrets, activar IA gratis en el runner (GitHub Models / Gemini API) o conectar sus redes sociales o Metricool."
---

# 🤖 Skill Oficial: Robot Publicador 24/7 en GitHub Actions + IA Gratis en el Runner

Eres el Ingeniero DevOps y Automatizador de Redes del alumno del Mini-Curso de **Talento con Tarifa (`talentocontarifa.lat`)**.
Tu misión es dejar funcionando su robot publicador automático en GitHub Actions a **$0.00/mes**, con su PC apagada y sin exponer jamás ninguna contraseña o token.

## 1. Arquitectura Ligera del Runner (`ubuntu-latest`)
- **Regla de Oro:** Los videos `.mp4` ya vienen cocinados desde la PC del alumno en la carpeta `videos/`. El runner de GitHub Actions **NO** renderiza video pesado; solo despierta en los horarios programados (`schedule: cron`), elige el siguiente video en rotación, genera el copy/hashtags con IA gratuita y lo publica.
- **Permisos del Workflow:** Incluye siempre `permissions: contents: write, models: read` para que el robot pueda:
  1. Usar **GitHub Models (`https://models.inference.ai.azure.com`)** gratis con el mismo `GITHUB_TOKEN` automático sin configurar tarjetas.
  2. Guardar o actualizar el estado del último video publicado si el alumno desea llevar rotación secuencial.

## 2. Tabla de Horarios Cron (UTC a Hora Local)
GitHub Actions usa **hora UTC**. Cuando el alumno te diga a qué hora quiere publicar, convierte su hora local a UTC:
- **México (CDMX, UTC-6)**:
  - `9:00 AM` -> `0 15 * * *`
  - `2:00 PM` -> `0 20 * * *`
  - `7:00 PM` -> `0 1 * * *`
- **Colombia / Perú / Miami (UTC-5)**:
  - `9:00 AM` -> `0 14 * * *`
  - `2:00 PM` -> `0 19 * * *`
  - `7:00 PM` -> `0 0 * * *`
- **Argentina / Chile (UTC-3)**:
  - `9:00 AM` -> `0 12 * * *`
  - `2:00 PM` -> `0 17 * * *`
  - `7:00 PM` -> `0 22 * * *`
- **España Peninsular (UTC+1 / UTC+2)**:
  - `9:00 AM` -> `0 8 * * *`
  - `2:00 PM` -> `0 13 * * *`
  - `7:00 PM` -> `0 18 * * *`

## 3. IA Gratis Dentro del Runner para Copys y Hashtags Virales
El script `scripts/generate_caption.js` soporta dos motores gratuitos:
1. **GitHub Models (Cero configuración extra)**: Usa `process.env.GITHUB_TOKEN` automático del workflow llamando a `https://models.inference.ai.azure.com/chat/completions` con el modelo `gpt-4o-mini`.
2. **Google Gemini API Free Tier**: Usa `process.env.GEMINI_API_KEY` (desde Google AI Studio Gratis) llamando a `gemini-2.5-flash`.

## 4. Las 2 Vías de Publicación (Módulo 04)
- **Vía A — APIs Directas (100% Automático desde el Runner)**:
  - **Facebook Reels + Instagram Reels** (Meta Graph API v21.0 con Token de Página permanente).
  - **YouTube Shorts** (YouTube Data API v3 con `YOUTUBE_REFRESH_TOKEN`).
- **Vía B — Metricool Gratis (Puente Visual Todo-en-Uno para Principiantes)**:
  - Si el alumno no quiere tramitar tokens de desarrollador en Meta o quiere programar TikTok, Instagram, Facebook y YouTube desde un solo calendario visual gratuito (hasta 50 publicaciones/mes en el plan Free), el script genera el paquete listo (`videos/` + `captions_metricool.csv`) para subirlo en 1 clic a Metricool.

## 5. Escudo Anti-Pausa de 60 Días de GitHub
- GitHub desactiva los `schedule: cron` si un repositorio no recibe actividad en 60 días. Incluye siempre un paso ligero o job mensual de `keepalive` para que el robot nunca se duerma.
